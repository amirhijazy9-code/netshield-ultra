from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    api_base_url: str = "http://localhost:8000"
    cors_origins: list[str] = ["http://localhost:3000", "https://netshield-ultra.pages.dev"]
    ipinfo_token: str = ""
    abuseipdb_key: str = ""
    ipqualityscore_key: str = ""
    # Optional OpenAI-compatible AI provider. Leave blank to use the built-in contextual analyst.
    ai_base_url: str = ""
    ai_api_key: str = ""
    ai_model: str = ""
    proxy_referral_url: str = "https://iproyal.com/?r=1528614"
    browser_referral_url: str = "https://www.adspower.com/share/GXxIGf"
    rate_limit_per_minute: int = 60
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
