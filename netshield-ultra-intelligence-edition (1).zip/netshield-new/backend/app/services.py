import asyncio, ipaddress, socket, ssl
from urllib.parse import urlparse
import httpx
import dns.resolver
from .security import is_private_or_reserved, validate_external_url

TIMEOUT=8.0

def _clean_domain(value:str)->str:
    value=value.strip().lower().rstrip('.')
    if '://' in value:
        value=urlparse(value).hostname or ''
    if not value or len(value)>253 or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789.-' for c in value):
        raise ValueError('Invalid domain')
    return value

async def lookup_ip(ip:str):
    addr=ipaddress.ip_address(ip); reverse=None
    try: reverse=socket.gethostbyaddr(ip)[0]
    except Exception: pass
    rdap=None
    async with httpx.AsyncClient(timeout=TIMEOUT,follow_redirects=True) as c:
        try:
            r=await c.get(f'https://rdap.org/ip/{ip}'); r.raise_for_status(); rdap=r.json()
        except Exception: pass
    return {'ip':ip,'version':addr.version,'private':addr.is_private,'reserved':addr.is_reserved,'loopback':addr.is_loopback,'reverse_dns':reverse,'rdap':rdap}

async def dns_lookup(domain:str):
    domain=_clean_domain(domain); result={}
    for record in ('A','AAAA','MX','NS','TXT','CNAME','CAA','SOA'):
        try: result[record]=[str(a) for a in dns.resolver.resolve(domain,record,lifetime=3)]
        except Exception: result[record]=[]
    return {'domain':domain,'records':result}

async def rdap_domain(domain:str):
    domain=_clean_domain(domain)
    async with httpx.AsyncClient(timeout=TIMEOUT,follow_redirects=True) as c:
        r=await c.get(f'https://rdap.org/domain/{domain}'); r.raise_for_status(); return r.json()

async def dns_google(domain:str, record:str):
    domain=_clean_domain(domain)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        r=await c.get('https://dns.google/resolve',params={'name':domain,'type':record}); r.raise_for_status(); return r.json()

async def reverse_dns(ip:str):
    ipaddress.ip_address(ip)
    try: return {'ip':ip,'ptr':socket.gethostbyaddr(ip)[0]}
    except Exception: return {'ip':ip,'ptr':None}

async def public_ip():
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        for url in ('https://api64.ipify.org?format=json','https://api.ipify.org?format=json'):
            try:
                r=await c.get(url); r.raise_for_status(); return r.json().get('ip')
            except Exception: pass
    return None

async def http_probe(url:str, follow:bool=False):
    validate_external_url(url)
    async with httpx.AsyncClient(timeout=TIMEOUT,follow_redirects=follow,max_redirects=8) as c:
        r=await c.get(url,headers={'User-Agent':'NetShield-HTTP-Diagnostic/1.0'})
        return {'url':url,'status':r.status_code,'headers':dict(r.headers),'final_url':str(r.url),'history':[{'status':x.status_code,'url':str(x.url),'location':x.headers.get('location')} for x in r.history]}

async def tls_probe(url:str):
    validate_external_url(url); p=urlparse(url); host=p.hostname; port=p.port or 443
    infos=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM)
    last=None
    for fam,typ,proto,_,sockaddr in infos:
        try:
            raw=socket.socket(fam,typ,proto); raw.settimeout(TIMEOUT)
            ctx=ssl.create_default_context(); ctx.check_hostname=True
            with ctx.wrap_socket(raw,server_hostname=host) as s:
                return {'host':host,'port':port,'tls_version':s.version(),'cipher':s.cipher(),'certificate_subject':dict(x[0] for x in s.getpeercert().get('subject',()))}
        except Exception as e: last=str(e)
    return {'host':host,'port':port,'error':last or 'TLS probe failed'}

async def tor_check(ip:str):
    ipaddress.ip_address(ip)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        try:
            r=await c.get('https://check.torproject.org/torbulkexitlist'); r.raise_for_status()
            exits=set(x.strip() for x in r.text.splitlines() if x.strip() and not x.startswith('#'))
            return {'ip':ip,'is_tor_exit':ip in exits,'source':'Tor Project exit list'}
        except Exception as e: return {'ip':ip,'is_tor_exit':None,'error':str(e)}

async def blacklist_check(ip:str):
    addr=ipaddress.ip_address(ip)
    if addr.version!=4: return {'ip':ip,'checked':False,'reason':'Public DNSBL query set supports IPv4 only'}
    rev='.'.join(reversed(ip.split('.')))
    lists=['zen.spamhaus.org','bl.spamcop.net','dnsbl.sorbs.net']
    hits=[]
    for zone in lists:
        try: socket.gethostbyname(f'{rev}.{zone}'); hits.append(zone)
        except Exception: pass
    return {'ip':ip,'checked':True,'hits':hits,'clean':not hits,'lists':lists}

async def full_scan(ip:str|None=None):
    if not ip: ip=await public_ip()
    findings=[]; score=100
    if ip:
        info=await lookup_ip(ip); findings.append({'category':'IP intelligence','result':info,'confidence':1.0})
        if info['private'] or info['reserved']:
            score-=30; findings.append({'category':'network','status':'warning','message':'Private/reserved address detected'})
    return {'privacy_score':max(0,score),'client_ip':ip,'findings':findings,'note':'Reputation/VPN/hosting labels are only reported when backed by a provider or verifiable signal.'}
