from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from .services import *
from .settings import settings
from .security import validate_external_url
from slowapi import Limiter
from slowapi.util import get_remote_address

router=APIRouter(prefix='/api'); limiter=Limiter(key_func=get_remote_address)
class DomainRequest(BaseModel): domain:str
class URLRequest(BaseModel): url:str
class ToolRequest(BaseModel): tool:str; target:str|None=None; extra:dict|None=None
class AssistantRequest(BaseModel): question:str; context:dict|None=None

@router.get('/ip/{ip}')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def ip_info(ip:str,request:Request):
    try:return await lookup_ip(ip)
    except ValueError:raise HTTPException(400,'Invalid IP address')

@router.post('/dns')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def dns_info(body:DomainRequest,request:Request):
    try:return await dns_lookup(body.domain)
    except ValueError as e: raise HTTPException(400,str(e))

@router.post('/url/validate')
async def validate_url(body:URLRequest,request:Request):
    try: validate_external_url(body.url); return {'allowed':True}
    except ValueError as e: raise HTTPException(400,str(e))

@router.get('/full-scan')
@limiter.limit('10/minute')
async def run_full_scan(request:Request): return await full_scan(request.client.host if request.client else None)

@router.post('/tool')
@limiter.limit('30/minute')
async def tool_run(body:ToolRequest,request:Request):
    t=body.tool.lower().strip(); target=(body.target or '').strip()
    try:
        if t in {'ip lookup','ip whois','asn lookup','hosting detect','vpn check','proxy check'}:
            ip=target or await public_ip()
            if not ip: raise HTTPException(400,'Public IP unavailable')
            info=await lookup_ip(ip)
            return {'tool':t,'result':info,'confidence':'direct RDAP/IP observation'}
        if t=='reverse dns': return {'tool':t,'result':await reverse_dns(target)}
        if t in {'dns lookup','dns spread','email security','dmarc check'}:
            domain=target
            if t=='dmarc check': domain='_dmarc.'+domain
            result=await dns_lookup(domain)
            return {'tool':t,'result':result}
        if t=='domain whois': return {'tool':t,'result':await rdap_domain(target)}
        if t in {'headers scan','security headers','redirects','cdn detect','hsts status','robots.txt','sitemap scan'}:
            url=target if '://' in target else 'https://'+target
            data=await http_probe(url,follow=t=='redirects')
            if t=='security headers':
                h={k.lower():v for k,v in data['headers'].items()}; names=['content-security-policy','strict-transport-security','x-content-type-options','x-frame-options','referrer-policy','permissions-policy']; data={'checked':url,'headers':{n:h.get(n) for n in names},'missing':[n for n in names if n not in h]}
            elif t=='hsts status': data={'checked':url,'hsts':data['headers'].get('strict-transport-security')}
            elif t=='cdn detect':
                h={k.lower():v for k,v in data['headers'].items()}; data={'checked':url,'provider_signals':{k:v for k,v in h.items() if k in ['server','cf-ray','x-cache','via','x-served-by','x-amz-cf-id']}}
            elif t=='robots.txt': data=await http_probe(url.rstrip('/')+'/robots.txt',False)
            elif t=='sitemap scan': data=await http_probe(url.rstrip('/')+'/sitemap.xml',False)
            return {'tool':t,'result':data}
        if t in {'tls checker','tls version'}:
            url=target if '://' in target else 'https://'+target
            return {'tool':t,'result':await tls_probe(url)}
        if t=='tor checker':
            ip=target or await public_ip(); return {'tool':t,'result':await tor_check(ip)}
        if t=='blacklist':
            ip=target or await public_ip(); return {'tool':t,'result':await blacklist_check(ip)}
        if t=='reverse ip':
            # No fabricated result: use a public lookup adapter when available.
            ip=target or await public_ip()
            async with httpx.AsyncClient(timeout=TIMEOUT) as c:
                r=await c.get('https://api.hackertarget.com/reverseiplookup/',params={'q':ip});
                return {'tool':t,'result':{'ip':ip,'raw':r.text,'source':'HackerTarget API'}}
        if t=='dns leak': return {'tool':t,'result':{'status':'not directly measurable from standard browser JS','guidance':'Use WebRTC and resolver checks; DNS server identity is controlled by the network.'}}
        return {'tool':t,'result':{'status':'local_only','message':'This tool is implemented in the browser and does not need a remote lookup.'}}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))

@router.post('/assistant')
@limiter.limit('30/minute')
async def assistant(body:AssistantRequest,request:Request):
    q=body.question.strip(); low=q.lower(); ctx=body.context or {}
    allowed_terms=['netshield','scan','audit','privacy','fingerprint','timezone','locale','ip','proxy','vpn','webrtc','webgl','dns','tool','risk','score','browser','network','report','offer','traffic','tracking','conversion','postback','attribution','quality','error','problem','مشكلة','فحص','أداة','بصمة','توقيت','عرض','ترافيك','تتبع','تحويل','بوست باك','مخاطر','درجة','شبكة','بروكسي','vpn','webrtc']
    if not any(x in low for x in allowed_terms):
        return {'answer':'أنا NetShield AI 🧠. تخصصي هو NetShield نفسه: نتائج الفحص، الأدوات، الخصوصية والبصمة، مشاكل الشبكة، وتشخيص جودة الـtraffic والـoffer tracking. اسألني عن مشكلة أو نتيجة محددة وسأحللها معاك خطوة بخطوة.'}
    b=ctx.get('browser',{}) or {}; score=ctx.get('score','—'); ip=ctx.get('ip','غير متاح'); tool=ctx.get('tool') or {}; scan=ctx.get('scan') or {}
    clues=[]
    if b.get('webdriver'): clues.append('إشارة WebDriver ظاهرة')
    if b.get('timezone') and b.get('locale'): clues.append(f"Timezone={b.get('timezone')} / Locale={b.get('locale')}")
    if tool and isinstance(tool,dict): clues.append(f"آخر أداة مفتوحة: {tool.get('name','غير محدد')}")
    context_line=' · '.join(clues) if clues else 'لا توجد إشارة إضافية حاسمة في السياق الحالي.'
    if any(x in low for x in ['offer','traffic','tracking','conversion','postback','attribution','عرض','ترافيك','تتبع','تحويل','بوست باك']):
        return {'answer':f"خلينا نشخّص المشكلة بدل التخمين. حالياً NetShield شايف Privacy/Signal Score = {score}/100 والـIP المرصود = {ip}. {context_line}\n\nلو المشكلة إن الـoffer لا يسجل أو الـconversion لا يظهر، افحص بالترتيب: 1) Redirect chain وHTTP status، 2) TLS/Headers، 3) DNS، 4) اتساق IP + timezone + locale + browser، 5) وصول endpoint الخاص بالتتبع من بيئتك. لو أرسلتلي نتيجة الأداة أو نص الخطأ، أقدر أحدد الاحتمال الأقرب وأقولك أي Tool تفتحه بعد كده. لن أقدم طرقاً لتجاوز أنظمة مكافحة الاحتيال أو الحظر."}
    if any(x in low for x in ['error','problem','مشكلة','خطأ']):
        return {'answer':f"تمام، هتعامل معاها كـincident داخل NetShield. السياق الحالي: Score={score}/100، IP={ip}. {context_line}\n\nابعت اسم الـTool أو رسالة الخطأ كما ظهرت. لو الخطأ متعلق بالـHTTP/SSL/DNS هنحدد هل المشكلة من DNS، TLS، redirect، headers، أو من الأداة نفسها، وبعدها أقولك الاختبار التالي بدل ما نجرب عشوائياً."}
    if 'score' in low or 'risk' in low or 'درجة' in low or 'مخاطر' in low:
        return {'answer':f'درجة NetShield الحالية {score}/100. الدرجة ليست حكماً على المستخدم؛ هي ملخص للإشارات التي استطاع الموقع قياسها. افتح Audit ثم الأدوات المرتبطة بأي CHECK، وأنا أقدر أفسر كل إشارة وأرتب لك خطة إصلاح حسب التأثير.'}
    if 'timezone' in low or 'locale' in low or 'توقيت' in low:
        return {'answer':f"Timezone: {b.get('timezone','غير متاح')} · Locale: {b.get('locale','غير متاح')}. NetShield يقارن الإشارات المتاحة ولا يعتبر أي قيمة منفردة إثباتاً لموقع حقيقي. لو شايف inconsistency افتح Timezone/Locale وIP Intelligence معاً."}
    if 'fingerprint' in low or 'browser' in low or 'بصمة' in low:
        return {'answer':f"Fingerprint Lab يقرأ الإشارات المتاحة للمتصفح مثل UA واللغات والشاشة وhardwareConcurrency وWebGL وWebDriver وCanvas. السياق الحالي: {context_line}. لو إشارة معينة مكتوب فيها Unavailable فهذا يعني أن المتصفح لم يسمح بقياسها، وليس أننا نخمن قيمتها."}
    if 'ip' in low: return {'answer':f'الـPublic IP المرصود حاليًا: {ip}. افتح IP Intelligence ثم IP WHOIS وReverse DNS وBlacklist/Tor عند الحاجة. لو النتيجة غير متوقعة، ابعتلي نتيجة IP Intelligence نفسها وأنا أفسرها.'}
    if 'dns' in low: return {'answer':'لـDNS استخدم DNS Lookup وReverse DNS وDNS Spread. لو المشكلة مرتبطة بموقع لا يفتح، قارن A/AAAA وNS/MX/TXT، ثم جرّب Headers/TLS للتأكد أن المشكلة ليست من طبقة HTTP.'}
    if 'proxy' in low or 'vpn' in low or 'بروكسي' in low:
        return {'answer':f"NetShield يقدر يعرض مؤشرات يمكن إثباتها عن الشبكة، لكنه لا يضمن تصنيف VPN/Proxy من إشارة واحدة. استخدم IP Intelligence وASN وReverse DNS وTor/Blacklist معاً، واعتبر أي نتيجة غير مؤكدة مجرد signal وليست حقيقة قطعية. الـIP الحالي: {ip}."}
    return {'answer':f"تمام. أنا شايف سياق الفحص الحالي: Score={score}/100، IP={ip}. {context_line}\n\nقولّي اسم الأداة أو المشكلة بالتحديد، وأنا أحولها لخطة تشخيص داخل NetShield خطوة بخطوة."}

@router.get('/referrals')
async def referrals(): return {'proxy':settings.proxy_referral_url or None,'browser':settings.browser_referral_url or None}
