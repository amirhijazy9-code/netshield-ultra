# IP Privacy Platform

A security-first IP / VPN / Proxy / DNS / Browser diagnostics platform starter.

## Included
- FastAPI backend
- Next.js frontend
- Full-scan orchestration
- IP / ASN / DNS basics
- VPN/proxy provider adapters
- Privacy scoring
- SSRF-safe URL inspection primitives
- Rate limiting hooks
- Security headers
- Docker Compose
- GitHub Actions security checks
- Configurable referral links
- Provider adapters designed so APIs can be added without rewriting the UI

## Important
No security system is guaranteed unbreakable. Run authorized security testing before production.

## Quick start

1. Copy `.env.example` to `.env`
2. Put provider API keys in `.env`
3. Run:
   docker compose up --build

Frontend: http://localhost:3000
API: http://localhost:8000
API docs: http://localhost:8000/docs

Referral URLs are configuration only; replace the example values with your own authorized affiliate/referral links.
