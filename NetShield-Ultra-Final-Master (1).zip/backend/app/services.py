import asyncio, ipaddress, socket, ssl, re
from urllib.parse import urlparse
import httpx
import dns.resolver
from .security import is_private_or_reserved, validate_external_url

TIMEOUT=8.0


def _clean_domain(value: str) -> str:
    value=value.strip().lower().rstrip('.')
    if '://' in value:
        value=urlparse(value).hostname or ''
    if not value or len(value)>253 or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789.-_' for c in value):
        raise ValueError('Invalid domain')
    if value.startswith('_'):
        value=value[1:]
    return value

async def lookup_ip(ip: str):
    addr=ipaddress.ip_address(ip); reverse=None
    try: reverse=socket.gethostbyaddr(ip)[0]
    except Exception: pass
    rdap=None
    async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as c:
        try:
            r=await c.get(f'https://rdap.org/ip/{ip}'); r.raise_for_status(); rdap=r.json()
        except Exception: pass
    org=None; asn=None; country=None
    if rdap:
        for ent in rdap.get('entities',[]) or []:
            for role in ent.get('roles',[]) or []:
                if role in ('registrant','administrative'):
                    v=ent.get('vcardArray',[None,[]])[1] if len(ent.get('vcardArray',[]))>1 else []
                    for item in v:
                        if isinstance(item,list) and len(item)>=4 and item[0]=='fn': org=item[3]
        asn=(rdap.get('name') or rdap.get('handle'))
        country=rdap.get('country')
    return {'ip':ip,'version':addr.version,'private':addr.is_private,'reserved':addr.is_reserved,'loopback':addr.is_loopback,
            'reverse_dns':reverse,'asn':asn,'organization':org,'country':country,'rdap':rdap,
            'classification_confidence':'high for IP ownership facts; low for VPN/proxy without a dedicated provider'}

async def dns_lookup(domain:str):
    domain=_clean_domain(domain); result={}
    for record in ('A','AAAA','MX','NS','TXT','CNAME','CAA','SOA'):
        try: result[record]=[str(a) for a in dns.resolver.resolve(domain,record,lifetime=3)]
        except Exception: result[record]=[]
    return {'domain':domain,'records':result}

async def rdap_domain(domain:str):
    domain=_clean_domain(domain)
    async with httpx.AsyncClient(timeout=TIMEOUT,follow_redirects=True) as c:
        r=await c.get(f'https://rdap.org/domain/{domain}'); r.raise_for_status(); return r.json()

async def public_ip():
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        for url in ('https://api64.ipify.org?format=json','https://api.ipify.org?format=json'):
            try:
                r=await c.get(url); r.raise_for_status(); return r.json().get('ip')
            except Exception: pass
    return None

async def reverse_dns(ip:str):
    ipaddress.ip_address(ip)
    try: return {'ip':ip,'ptr':socket.gethostbyaddr(ip)[0]}
    except Exception: return {'ip':ip,'ptr':None}

async def dns_google(domain:str, record:str):
    domain=_clean_domain(domain)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        r=await c.get('https://dns.google/resolve',params={'name':domain,'type':record}); r.raise_for_status(); return r.json()

async def dns_spread(domain: str):
    domain=_clean_domain(domain)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        a,b=await asyncio.gather(
            c.get('https://dns.google/resolve',params={'name':domain,'type':'A'}),
            c.get('https://cloudflare-dns.com/dns-query',params={'name':domain,'type':'A'},headers={'accept':'application/dns-json'})
        )
    ga=[x.get('data') for x in a.json().get('Answer',[]) if x.get('type')==1]
    ca=[x.get('data') for x in b.json().get('Answer',[]) if x.get('type')==1]
    return {'domain':domain,'google':ga,'cloudflare':ca,'match':set(ga)==set(ca)}

def _spf_from_txt(txts):
    return [x for x in txts if x.lower().startswith('v=spf1')]

async def email_security(domain: str, selector: str|None=None):
    domain=_clean_domain(domain)
    dns=await dns_lookup(domain)
    txt=dns['records'].get('TXT',[])
    spf=_spf_from_txt(txt)
    dmarc=[]
    try: dmarc=(await dns_lookup('_dmarc.'+domain))['records'].get('TXT',[])
    except Exception: pass
    dkim=None
    if selector:
        try: dkim=(await dns_lookup(f'{selector}._domainkey.{domain}'))['records']
        except Exception as e: dkim={'error':str(e)}
    return {'domain':domain,'mx':dns['records'].get('MX',[]),'spf':spf,'dmarc':dmarc,'dkim':dkim,
            'dkim_note':'DKIM cannot be confirmed without a selector; provide one when you know it.' if not selector else 'Selector-tested DNS lookup.'}

async def http_probe(url:str, follow:bool=False):
    validate_external_url(url)
    async with httpx.AsyncClient(timeout=TIMEOUT,follow_redirects=follow,max_redirects=8) as c:
        r=await c.get(url,headers={'User-Agent':'NetShield-Diagnostic/2.0'})
        return {'url':url,'status':r.status_code,'ok':200<=r.status_code<400,'headers':dict(r.headers),
                'content_type':r.headers.get('content-type'),'content_length':r.headers.get('content-length'),
                'final_url':str(r.url),'history':[{'status':x.status_code,'url':str(x.url),'location':x.headers.get('location')} for x in r.history]}

async def tls_probe(url:str):
    validate_external_url(url); p=urlparse(url); host=p.hostname; port=p.port or 443
    infos=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM); last=None
    for fam,typ,proto,_,sockaddr in infos:
        try:
            raw=socket.socket(fam,typ,proto); raw.settimeout(TIMEOUT)
            ctx=ssl.create_default_context(); ctx.check_hostname=True
            with ctx.wrap_socket(raw,server_hostname=host) as s:
                cert=s.getpeercert()
                subject={x[0]:x[1] for x in cert.get('subject',())}
                issuer={x[0]:x[1] for x in cert.get('issuer',())}
                return {'host':host,'port':port,'tls_version':s.version(),'cipher':s.cipher(),
                        'certificate_subject':subject,'certificate_issuer':issuer,
                        'alpn':s.selected_alpn_protocol()}
        except Exception as e: last=str(e)
    return {'host':host,'port':port,'error':last or 'TLS probe failed'}

async def tor_check(ip:str):
    ipaddress.ip_address(ip)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        try:
            r=await c.get('https://check.torproject.org/torbulkexitlist'); r.raise_for_status()
            exits=set(x.strip() for x in r.text.splitlines() if x.strip() and not x.startswith('#'))
            return {'ip':ip,'is_tor_exit':ip in exits,'source':'Tor Project exit list','confidence':'direct list membership'}
        except Exception as e: return {'ip':ip,'is_tor_exit':None,'error':str(e)}

async def blacklist_check(ip:str):
    addr=ipaddress.ip_address(ip)
    if addr.version!=4: return {'ip':ip,'checked':False,'reason':'IPv4 DNSBL query set only','status':'unavailable'}
    rev='.'.join(reversed(ip.split('.'))); lists=['zen.spamhaus.org','bl.spamcop.net','dnsbl.sorbs.net']; hits=[]
    for zone in lists:
        try: socket.gethostbyname(f'{rev}.{zone}'); hits.append(zone)
        except Exception: pass
    return {'ip':ip,'checked':True,'hits':hits,'clean':not hits,'lists':lists,'source':'DNSBL queries'}

async def reverse_ip(ip:str):
    ipaddress.ip_address(ip)
    async with httpx.AsyncClient(timeout=TIMEOUT) as c:
        r=await c.get('https://api.hackertarget.com/reverseiplookup/',params={'q':ip});
        return {'ip':ip,'raw':r.text,'source':'HackerTarget API','disclaimer':'Third-party lookup; content may be incomplete.'}

async def full_scan(ip:str|None=None):
    if not ip: ip=await public_ip()
    if not ip: return {'privacy_score':0,'client_ip':None,'status':'unavailable','findings':[]}
    info,ptr,tor,black = await asyncio.gather(lookup_ip(ip), reverse_dns(ip), tor_check(ip), blacklist_check(ip), return_exceptions=True)
    findings=[]; score=100; factors=[]
    if not isinstance(info,Exception):
        findings.append({'category':'IP intelligence','status':'pass','result':info,'confidence':'high'})
        if info['private'] or info['reserved']:
            score-=35; factors.append('Private/reserved IP classification')
    if not isinstance(ptr,Exception): findings.append({'category':'Reverse DNS','status':'pass','result':ptr,'confidence':'direct resolver observation'})
    if not isinstance(tor,Exception) and tor.get('is_tor_exit') is not None:
        findings.append({'category':'Tor exit status','status':'warning' if tor.get('is_tor_exit') else 'pass','result':tor,'confidence':'direct Tor exit-list membership'})
        if tor.get('is_tor_exit'): score-=35; factors.append('IP appears on current Tor exit list')
    if not isinstance(black,Exception) and black.get('checked'):
        findings.append({'category':'DNSBL reputation','status':'warning' if not black.get('clean') else 'pass','result':black,'confidence':'queried listed DNSBL zones'})
        if not black.get('clean'): score-=20; factors.append('IP matched at least one queried DNSBL')
    return {'privacy_score':max(0,score),'client_ip':ip,'status':'complete','findings':findings,'risk_factors':factors,
            'method':'Evidence-based scoring. Unavailable signals do not count as failures.'}

async def ai_complete(question: str, context: dict, settings):
    if not settings.ai_base_url or not settings.ai_api_key or not settings.ai_model:
        return None
    system='''You are NetShield AI Investigator. Be friendly and conversational. Answer naturally in Arabic, English, or Russian according to the user\'s language. Stay focused on NetShield product usage, diagnostics, privacy/network/fingerprint explanations, and legitimate offer/traffic troubleshooting. Do not help bypass fraud controls, bans, identity checks, or platform security. Use only the supplied audit context; say when data is missing. Explain evidence, confidence, likely causes, next diagnostic step, and safe remediation. Never invent a scan result.'''
    payload={'model':settings.ai_model,'messages':[{'role':'system','content':system},{'role':'user','content':question+'\n\nAUDIT_CONTEXT:\n'+str(context)}], 'temperature':0.25}
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.post(settings.ai_base_url,headers={'Authorization':f'Bearer {settings.ai_api_key}','Content-Type':'application/json'},json=payload)
        r.raise_for_status(); data=r.json()
    return data.get('choices',[{}])[0].get('message',{}).get('content')
