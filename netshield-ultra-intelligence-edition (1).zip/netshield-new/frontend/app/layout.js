import './globals.css';
export const metadata={title:'NetShield Ultra | Privacy, Network & Traffic Intelligence',description:'NetShield Ultra analyzes IP, browser fingerprint, privacy signals, network health and offer/traffic diagnostics.',keywords:['NetShield','IP intelligence','privacy audit','browser fingerprint','network diagnostics','traffic diagnostics','offer diagnostics'],openGraph:{title:'NetShield Ultra',description:'Privacy, Network & Traffic Intelligence'}};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
