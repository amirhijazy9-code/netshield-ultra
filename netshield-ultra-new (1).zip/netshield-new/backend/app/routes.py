from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from .services import lookup_ip, dns_lookup, full_scan
from .settings import settings
from .security import validate_external_url
from slowapi import Limiter
from slowapi.util import get_remote_address

router=APIRouter(prefix='/api')
limiter=Limiter(key_func=get_remote_address)
class DomainRequest(BaseModel): domain:str
class URLRequest(BaseModel): url:str
class AssistantRequest(BaseModel): question:str; context:dict|None=None

@router.get('/ip/{ip}')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def ip_info(ip:str,request:Request):
 try:return await lookup_ip(ip)
 except ValueError:raise HTTPException(400,'Invalid IP address')

@router.post('/dns')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def dns_info(body:DomainRequest,request:Request): return await dns_lookup(body.domain)

@router.post('/url/validate')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def validate_url(body:URLRequest,request:Request):
 try: validate_external_url(body.url); return {'allowed':True}
 except ValueError as e: raise HTTPException(400,str(e))

@router.get('/full-scan')
@limiter.limit('10/minute')
async def run_full_scan(request:Request):
 client_ip=request.client.host if request.client else None
 return await full_scan(client_ip)

@router.post('/assistant')
@limiter.limit('30/minute')
async def assistant(body:AssistantRequest,request:Request):
 q=body.question.lower().strip(); ctx=body.context or {}; score=ctx.get('score','—')
 allowed=('netshield','scan','audit','privacy','fingerprint','timezone','locale','ip','proxy','vpn','webrtc','webgl','dns','tool','risk','score','browser','network','report','site','website')
 if not any(x in q for x in allowed):
  return {'answer':'أنا NetShield AI ومهمتي داخل الموقع فقط. أقدر أشرح نتائج الفحص، أدوات NetShield، الـIP، البصمة، الخصوصية، الـrisk score أو طريقة استخدام الموقع.'}
 if 'score' in q or 'risk' in q:
  return {'answer':f'الـPrivacy posture الحالي في لوحة NetShield هو {score}/100. الدرجة تجميعية من الإشارات المتاحة، وليست حكمًا مطلقًا على أمانك. راجع قسم Live findings لمعرفة الأسباب الفعلية.'}
 if 'timezone' in q or 'locale' in q:
  return {'answer':f"Timezone الحالي: {ctx.get('browser',{}).get('timezone','غير متاح')} · Locale: {ctx.get('browser',{}).get('locale','غير متاح')}. NetShield يعرض القيم كما يراها المتصفح ولا يفترض أنها صحيحة خارج هذا السياق."}
 if 'fingerprint' in q or 'browser' in q:
  return {'answer':'Fingerprint Lab يعرض إشارات المتصفح المتاحة للصفحة مثل User-Agent، اللغة، الشاشة، hardwareConcurrency، WebGL وWebDriver. عدم ظهور إشارة لا يعني أنها مستحيلة الاكتشاف في كل السياقات.'}
 if 'ip' in q:
  return {'answer':f"الـIP الذي استطاع الـAPI رؤيته حاليًا: {ctx.get('ip','غير متاح')}. استخدم IP Intelligence للحصول على تفاصيل العنوان المتاحة فعليًا."}
 return {'answer':'أقدر أساعدك في فهم نتائج NetShield الحالية أو شرح أداة من الـToolbox. اكتب اسم الأداة أو النتيجة التي تريد تفسيرها.'}

@router.get('/referrals')
async def referrals(): return {'proxy':settings.proxy_referral_url or None,'browser':settings.browser_referral_url or None}
