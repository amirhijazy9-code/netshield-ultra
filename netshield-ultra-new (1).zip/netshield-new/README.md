# NetShield Ultra — Privacy Intelligence Edition

A transparent privacy/IP/browser diagnostic dashboard built from the original project.

## Principles
- Never fabricate diagnostic values.
- Local browser signals are clearly labeled.
- Server-observed network data is clearly labeled.
- The AI assistant is scope-limited to NetShield, its tools, diagnostics, and privacy results.
- Provider integrations for reputation/ASN/geo/VPN/proxy can be added through backend adapters.

## Run
### Frontend
```bash
cd frontend
npm install
npm run dev
```
Set `NEXT_PUBLIC_API_URL` to the FastAPI URL when needed.

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
