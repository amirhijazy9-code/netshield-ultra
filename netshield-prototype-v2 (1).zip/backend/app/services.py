import socket, ipaddress
import dns.resolver
from .security import is_private_or_reserved

async def lookup_ip(ip: str):
    addr = ipaddress.ip_address(ip)
    reverse = None
    try: reverse = socket.gethostbyaddr(ip)[0]
    except Exception: pass
    return {"ip": ip, "version": addr.version, "private": addr.is_private, "reserved": addr.is_reserved, "loopback": addr.is_loopback, "reverse_dns": reverse}

async def dns_lookup(domain: str):
    result = {}
    for record in ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "CAA"):
        try:
            answers = dns.resolver.resolve(domain, record, lifetime=3)
            result[record] = [str(a) for a in answers]
        except Exception: result[record] = []
    return result

async def full_scan(ip: str | None = None):
    findings=[]; score=100
    if ip:
        result=await lookup_ip(ip)
        findings.append({"category":"ip","result":result,"confidence":1.0})
        if is_private_or_reserved(ip):
            score-=30; findings.append({"category":"network","status":"warning","message":"Private/reserved address detected"})
    return {"privacy_score":max(0,score),"findings":findings,"note":"This scan reports observable diagnostics only. ASN, ISP, VPN/proxy and reputation intelligence are adapter-ready and require authorized provider APIs."}
