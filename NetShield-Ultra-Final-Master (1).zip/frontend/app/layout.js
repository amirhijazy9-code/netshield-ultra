import './globals.css';

export const metadata={
 title:'NetShield Ultra | Privacy, Network & Traffic Intelligence',
 description:'Evidence-based IP, browser fingerprint, device, network, privacy and traffic diagnostics.',
 openGraph:{title:'NetShield Ultra',description:'Privacy, Network, Fingerprint & Traffic Intelligence',url:'https://netshield-ultra.pages.dev/',siteName:'NetShield Ultra',type:'website'},
 metadataBase:new URL('https://netshield-ultra.pages.dev/')
};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
