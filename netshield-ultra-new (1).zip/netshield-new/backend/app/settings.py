from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    api_base_url: str = "http://localhost:8000"
    cors_origins: list[str] = ["http://localhost:3000"]
    ipinfo_token: str = ""
    abuseipdb_key: str = ""
    ipqualityscore_key: str = ""
    proxy_referral_url: str = ""
    browser_referral_url: str = ""
    rate_limit_per_minute: int = 60
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
