import './globals.css';
export const metadata = {
  title: "NetShield — Privacy Intelligence",
  description: "IP, browser fingerprint, network, timezone and privacy diagnostics",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
