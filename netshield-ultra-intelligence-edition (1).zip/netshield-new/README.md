# NetShield Ultra

Privacy, Network & Traffic Intelligence platform.

## What changed in this edition
- New NetShield Ultra branding and SEO metadata.
- Real browser diagnostics: timezone, locale, hardware hints, WebGL, WebDriver, canvas fingerprint signal and WebRTC ICE exposure test.
- 36-tool toolbox with local calculations and backend-backed diagnostics where the browser can verify the result.
- RDAP/IP intelligence, DNS, reverse DNS, domain RDAP, HTTP headers, redirects, TLS negotiation, Tor exit-list and DNSBL checks.
- Offer & Traffic Intelligence section for troubleshooting tracking quality, redirect chains, postback reachability and signal consistency.
- NetShield AI is scoped to the site, diagnostics and offer/traffic troubleshooting; it refuses unrelated questions and does not provide anti-fraud bypass instructions.
- No fabricated reputation values: unsupported checks are labeled unavailable/passive-only.

## Important deployment note
The frontend can run as a static Next.js site, but backend-backed tools need the FastAPI service deployed somewhere reachable by HTTPS. Set `NEXT_PUBLIC_API_URL` in the frontend deployment to that API origin and configure `CORS_ORIGINS`/`cors_origins` accordingly.

Do not place private API keys in browser code. Provider keys belong in backend environment variables.
