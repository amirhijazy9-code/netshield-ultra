import ipaddress, socket
from urllib.parse import urlparse
PRIVATE_NETWORKS=[ipaddress.ip_network(x) for x in ['10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','127.0.0.0/8','169.254.0.0/16','::1/128','fc00::/7','fe80::/10']]
def is_private_or_reserved(host:str)->bool:
    try:
        ip=ipaddress.ip_address(host); return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or any(ip in n for n in PRIVATE_NETWORKS)
    except ValueError: return False

def validate_external_url(url:str)->str:
    p=urlparse(url)
    if p.scheme not in {'http','https'}: raise ValueError('Only HTTP/HTTPS URLs are allowed')
    if not p.hostname: raise ValueError('URL hostname is required')
    host=p.hostname
    if is_private_or_reserved(host): raise ValueError('Private/reserved destinations are blocked')
    try:
        infos=socket.getaddrinfo(host,p.port or (443 if p.scheme=='https' else 80),type=socket.SOCK_STREAM)
        if not infos: raise ValueError('Host did not resolve')
        for item in infos:
            resolved=item[4][0]
            if is_private_or_reserved(resolved): raise ValueError('Destination resolves to a private/reserved address')
    except socket.gaierror as e: raise ValueError(f'Host resolution failed: {e}')
    return url
