from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from .services import *
from .settings import settings
from .security import validate_external_url
from slowapi import Limiter
from slowapi.util import get_remote_address

router=APIRouter(prefix='/api'); limiter=Limiter(key_func=get_remote_address)
class DomainRequest(BaseModel): domain:str
class URLRequest(BaseModel): url:str
class ToolRequest(BaseModel): tool:str; target:str|None=None; extra:dict|None=None
class AssistantRequest(BaseModel): question:str; context:dict|None=None

@router.get('/ip/{ip}')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def ip_info(ip:str,request:Request):
    try:return await lookup_ip(ip)
    except ValueError:raise HTTPException(400,'Invalid IP address')

@router.post('/dns')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def dns_info(body:DomainRequest,request:Request):
    try:return await dns_lookup(body.domain)
    except ValueError as e: raise HTTPException(400,str(e))

@router.post('/url/validate')
async def validate_url(body:URLRequest,request:Request):
    try: validate_external_url(body.url); return {'allowed':True}
    except ValueError as e: raise HTTPException(400,str(e))

@router.get('/full-scan')
@limiter.limit('10/minute')
async def run_full_scan(request:Request): return await full_scan(request.client.host if request.client else None)

@router.post('/tool')
@limiter.limit('30/minute')
async def tool_run(body:ToolRequest,request:Request):
    t=body.tool.lower().strip(); target=(body.target or '').strip()
    try:
        if t in {'ip lookup','ip whois','asn lookup','hosting detect','vpn check','proxy check'}:
            ip=target or await public_ip()
            if not ip: raise HTTPException(400,'Public IP unavailable')
            info=await lookup_ip(ip)
            return {'tool':t,'result':info,'confidence':'direct RDAP/IP observation'}
        if t=='reverse dns': return {'tool':t,'result':await reverse_dns(target)}
        if t in {'dns lookup','dns spread','email security','dmarc check'}:
            domain=target
            if t=='dmarc check': domain='_dmarc.'+domain
            result=await dns_lookup(domain)
            return {'tool':t,'result':result}
        if t=='domain whois': return {'tool':t,'result':await rdap_domain(target)}
        if t in {'headers scan','security headers','redirects','cdn detect','hsts status','robots.txt','sitemap scan'}:
            url=target if '://' in target else 'https://'+target
            data=await http_probe(url,follow=t=='redirects')
            if t=='security headers':
                h={k.lower():v for k,v in data['headers'].items()}; names=['content-security-policy','strict-transport-security','x-content-type-options','x-frame-options','referrer-policy','permissions-policy']; data={'checked':url,'headers':{n:h.get(n) for n in names},'missing':[n for n in names if n not in h]}
            elif t=='hsts status': data={'checked':url,'hsts':data['headers'].get('strict-transport-security')}
            elif t=='cdn detect':
                h={k.lower():v for k,v in data['headers'].items()}; data={'checked':url,'provider_signals':{k:v for k,v in h.items() if k in ['server','cf-ray','x-cache','via','x-served-by','x-amz-cf-id']}}
            elif t=='robots.txt': data=await http_probe(url.rstrip('/')+'/robots.txt',False)
            elif t=='sitemap scan': data=await http_probe(url.rstrip('/')+'/sitemap.xml',False)
            return {'tool':t,'result':data}
        if t in {'tls checker','tls version'}:
            url=target if '://' in target else 'https://'+target
            return {'tool':t,'result':await tls_probe(url)}
        if t=='tor checker':
            ip=target or await public_ip(); return {'tool':t,'result':await tor_check(ip)}
        if t=='blacklist':
            ip=target or await public_ip(); return {'tool':t,'result':await blacklist_check(ip)}
        if t=='reverse ip':
            # No fabricated result: use a public lookup adapter when available.
            ip=target or await public_ip()
            async with httpx.AsyncClient(timeout=TIMEOUT) as c:
                r=await c.get('https://api.hackertarget.com/reverseiplookup/',params={'q':ip});
                return {'tool':t,'result':{'ip':ip,'raw':r.text,'source':'HackerTarget API'}}
        if t=='dns leak': return {'tool':t,'result':{'status':'not directly measurable from standard browser JS','guidance':'Use WebRTC and resolver checks; DNS server identity is controlled by the network.'}}
        return {'tool':t,'result':{'status':'local_only','message':'This tool is implemented in the browser and does not need a remote lookup.'}}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))

@router.post('/assistant')
@limiter.limit('30/minute')
async def assistant(body:AssistantRequest,request:Request):
    q=body.question.strip(); low=q.lower(); ctx=body.context or {}
    allowed_terms=['netshield','scan','audit','privacy','fingerprint','timezone','locale','ip','proxy','vpn','webrtc','webgl','dns','tool','risk','score','browser','network','report','offer','traffic','tracking','conversion','postback','attribution','quality']
    if not any(x in low for x in allowed_terms):
        return {'answer':'أنا NetShield AI. أقدر أساعدك فقط في NetShield، نتائج الفحص، أدوات الموقع، الخصوصية/البصمة، وتشخيص جودة الـtraffic والـoffer tracking. مش هجاوب على أسئلة خارج نطاق الموقع.'}
    b=ctx.get('browser',{}); score=ctx.get('score','—'); ip=ctx.get('ip','غير متاح')
    if any(x in low for x in ['offer','traffic','tracking','conversion','postback','attribution']):
        return {'answer':f'أقدر أساعدك في تشخيص الـOffer/Traffic داخل NetShield: راجع اتساق IP + timezone + locale + browser signals، وتأكد من صحة tracking/postback من جهة النظام. الـPrivacy score الحالي {score}/100 والـIP المرصود {ip}. لا أقدم خطوات لتجاوز أنظمة مكافحة الاحتيال أو الحظر.'}
    if 'score' in low or 'risk' in low:
        return {'answer':f'درجة NetShield الحالية {score}/100. لا تعتمد على الرقم وحده؛ افتح Audit وشوف كل إشارة ودرجة الثقة والسبب، ثم أصلح المشاكل الأعلى تأثيرًا أولًا.'}
    if 'timezone' in low or 'locale' in low:
        return {'answer':f"Timezone: {b.get('timezone','غير متاح')} · Locale: {b.get('locale','غير متاح')}. NetShield يقارن الاتساق بين إشارات المتصفح المتاحة، ولا يفترض أن أي إشارة منفردة تثبت موقعك الحقيقي."}
    if 'fingerprint' in low or 'browser' in low:
        return {'answer':'Fingerprint Lab يجمع User-Agent واللغات والشاشة وhardwareConcurrency وWebGL وWebDriver وإشارات قدرات المتصفح المتاحة. بعض الإشارات قد تكون محجوبة حسب المتصفح، لذلك نعرض unavailable بدل التخمين.'}
    if 'ip' in low: return {'answer':f'الـPublic IP المرصود حاليًا: {ip}. استخدم IP Intelligence وIP WHOIS وReverse DNS لمعرفة التفاصيل التي يمكن إثباتها.'}
    return {'answer':'ابعتلي اسم أداة NetShield أو نتيجة محددة من الـAudit، وأنا أشرحها لك وأقولك إيه اللي محتاج مراجعة.'}

@router.get('/referrals')
async def referrals(): return {'proxy':settings.proxy_referral_url or None,'browser':settings.browser_referral_url or None}
