from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from .services import lookup_ip, dns_lookup, full_scan
from .settings import settings
from .security import validate_external_url
from slowapi import Limiter
from slowapi.util import get_remote_address

router = APIRouter(prefix="/api")
limiter = Limiter(key_func=get_remote_address)

class DomainRequest(BaseModel):
    domain: str

class URLRequest(BaseModel):
    url: str

@router.get("/ip/{ip}")
@limiter.limit(f"{settings.rate_limit_per_minute}/minute")
async def ip_info(ip: str, request: Request):
    try:
        return await lookup_ip(ip)
    except ValueError:
        raise HTTPException(400, "Invalid IP address")

@router.post("/dns")
@limiter.limit(f"{settings.rate_limit_per_minute}/minute")
async def dns_info(body: DomainRequest, request: Request):
    return await dns_lookup(body.domain)

@router.post("/url/validate")
@limiter.limit(f"{settings.rate_limit_per_minute}/minute")
async def validate_url(body: URLRequest, request: Request):
    try:
        validate_external_url(body.url)
        return {"allowed": True}
    except ValueError as e:
        raise HTTPException(400, str(e))

@router.get("/full-scan")
@limiter.limit("10/minute")
async def run_full_scan(request: Request):
    client_ip = request.client.host if request.client else None
    return await full_scan(client_ip)

@router.get("/referrals")
async def referrals():
    return {
        "proxy": settings.proxy_referral_url or None,
        "browser": settings.browser_referral_url or None
    }
