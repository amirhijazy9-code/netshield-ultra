# NetShield Ultra — Intelligence Edition v3

Privacy, Network, Fingerprint & Traffic Intelligence platform.

## v3 fixes and upgrades
- Fixed the initial-load false red state: the UI now uses scanning/waiting states until evidence is available.
- Removed the stale `setLastTool`/`setToolHistory` runtime bug from the previous frontend.
- Full audit initializes automatically and can be rerun without a page refresh.
- WebRTC runs automatically after browser initialization and is shown as a measured state.
- Toolbox opens a tool and automatically runs it when a safe/current target is available; every run receives a timestamp and duration.
- Added Device & Environment Lab: mobile/desktop-like profile, touch, renderer, automation and virtualization clues.
- Device classification is explicitly presented as an inference. A web page cannot prove physical vs cloud phone/emulator/remote desktop from browser JavaScript alone.
- Added recent tool-run history and a unified evidence report.
- AI context now includes device assessment, tool result and recent tool runs.
- Offer/Traffic Intelligence focuses on technical diagnostics: redirect chains, endpoint reachability, DNS/TLS, signal consistency and attribution troubleshooting. It does not provide anti-fraud bypass instructions.
- Unsupported checks are labeled unavailable/passive-only rather than fabricated.

## Deployment
The frontend can run on a static/Next-compatible host. Server-backed tools require the FastAPI service to be deployed over HTTPS and `NEXT_PUBLIC_API_URL` set to that API origin.

Do not place provider API keys in frontend code. Keep secrets in backend environment variables.

## Master version policy
Treat this ZIP as the new master. Future edits should be made from this version only; keep older ZIPs as backups and do not merge files from different generations manually.
