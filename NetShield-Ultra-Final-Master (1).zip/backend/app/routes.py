from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from .services import *
from .settings import settings
from .security import validate_external_url
from slowapi import Limiter
from slowapi.util import get_remote_address

router=APIRouter(prefix='/api'); limiter=Limiter(key_func=get_remote_address)
class DomainRequest(BaseModel): domain:str
class URLRequest(BaseModel): url:str
class ToolRequest(BaseModel): tool:str; target:str|None=None; extra:dict|None=None
class AssistantRequest(BaseModel): question:str; context:dict|None=None

@router.get('/full-scan')
@limiter.limit('10/minute')
async def run_full_scan(request:Request): return await full_scan(request.client.host if request.client else None)

@router.get('/ip/{ip}')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def ip_info(ip:str,request:Request):
    try:return await lookup_ip(ip)
    except ValueError:raise HTTPException(400,'Invalid IP address')

@router.post('/dns')
@limiter.limit(f'{settings.rate_limit_per_minute}/minute')
async def dns_info(body:DomainRequest,request:Request):
    try:return await dns_lookup(body.domain)
    except ValueError as e: raise HTTPException(400,str(e))

@router.post('/url/validate')
async def validate_url(body:URLRequest,request:Request):
    try: validate_external_url(body.url); return {'allowed':True}
    except ValueError as e: raise HTTPException(400,str(e))

@router.post('/tool')
@limiter.limit('30/minute')
async def tool_run(body:ToolRequest,request:Request):
    t=body.tool.lower().strip(); target=(body.target or '').strip(); extra=body.extra or {}
    try:
        if t in {'ip lookup','ip whois','asn lookup','hosting detect','vpn check','proxy check'}:
            ip=target or await public_ip()
            if not ip: raise HTTPException(400,'Public IP unavailable')
            info=await lookup_ip(ip)
            if t=='hosting detect':
                org=(info.get('organization') or '').lower();
                flags=[k for k in ('amazon','google','microsoft','azure','digitalocean','ovh','hetzner','cloudflare','linode','vultr') if k in org]
                info={'ip':ip,'organization':info.get('organization'),'asn':info.get('asn'),'hosting_signals':flags,'confidence':'heuristic from RDAP organization; not a definitive hosting classification'}
            elif t in {'vpn check','proxy check'}:
                info={'ip':ip,'status':'inconclusive_without_reputation_provider','observed_network_identity':info.get('organization'),'note':'A website cannot reliably prove VPN/proxy use from RDAP alone. Add a reputation provider key for stronger classification.'}
            return {'tool':t,'result':info}
        if t=='reverse ip': return {'tool':t,'result':await reverse_ip(target or await public_ip())}
        if t=='reverse dns': return {'tool':t,'result':await reverse_dns(target)}
        if t=='dns spread': return {'tool':t,'result':await dns_spread(target)}
        if t=='domain whois': return {'tool':t,'result':await rdap_domain(target)}
        if t in {'dns lookup','email security','dmarc check'}:
            if t=='email security': return {'tool':t,'result':await email_security(target, extra.get('dkim_selector'))}
            domain='_dmarc.'+target if t=='dmarc check' else target
            return {'tool':t,'result':await dns_lookup(domain)}
        if t in {'headers scan','security headers','redirects','cdn detect','hsts status','robots.txt','sitemap scan'}:
            url=target if '://' in target else 'https://'+target
            if t=='robots.txt': url=url.rstrip('/')+'/robots.txt'
            if t=='sitemap scan': url=url.rstrip('/')+'/sitemap.xml'
            data=await http_probe(url,follow=t=='redirects')
            if t=='security headers':
                h={k.lower():v for k,v in data['headers'].items()}; names=['content-security-policy','strict-transport-security','x-content-type-options','x-frame-options','referrer-policy','permissions-policy']; data={'checked':url,'status':data['status'],'headers':{n:h.get(n) for n in names},'missing':[n for n in names if n not in h]}
            elif t=='hsts status': data={'checked':url,'status':data['status'],'hsts':data['headers'].get('strict-transport-security')}
            elif t=='cdn detect':
                h={k.lower():v for k,v in data['headers'].items()}; data={'checked':url,'status':data['status'],'provider_signals':{k:v for k,v in h.items() if k in ['server','cf-ray','x-cache','via','x-served-by','x-amz-cf-id']}}
            return {'tool':t,'result':data}
        if t in {'tls checker','tls version'}:
            url=target if '://' in target else 'https://'+target
            return {'tool':t,'result':await tls_probe(url)}
        if t=='tor checker': return {'tool':t,'result':await tor_check(target or await public_ip())}
        if t=='blacklist': return {'tool':t,'result':await blacklist_check(target or await public_ip())}
        if t=='dns leak': return {'tool':t,'result':{'status':'limited','confidence':'high on limitation','message':'A normal webpage cannot directly reveal every DNS resolver used by the device. Pair this with WebRTC and observed network tests.'}}
        if t=='safe ports': return {'tool':t,'result':{'status':'passive_only','policy':'NetShield does not perform arbitrary port scanning. Use HTTP/TLS/headers diagnostics on infrastructure you own or are authorized to test.'}}
        raise HTTPException(400,'This tool needs a browser-side runner or an input-specific implementation; no fake result is returned.')
    except HTTPException: raise
    except ValueError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(500,str(e))

@router.post('/assistant')
@limiter.limit('30/minute')
async def assistant(body:AssistantRequest,request:Request):
    q=body.question.strip(); ctx=body.context or {}
    if not q: return {'answer':'قولّي اللي عايز تعرفه عن NetShield وأنا معاك 👋','language':'ar'}
    # Prefer a real model when configured.
    try:
        answer=await ai_complete(q,ctx,settings)
        if answer: return {'answer':answer,'provider':'configured-ai'}
    except Exception as e:
        # Do not expose secrets/provider internals to the user.
        pass
    b=ctx.get('browser',{}) or {}; score=ctx.get('score','—'); ip=ctx.get('ip','غير متاح'); tool=ctx.get('tool') or {}; analysis=ctx.get('analysis') or {}
    # Friendly, non-gated fallback. Short greetings and conversational text get normal replies.
    ar=any(c in q for c in 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي')
    ru=any(c in q for c in 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
    if ru:
        lang='ru'; hello='Привет 👋 Я NetShield AI. Давай разберём результат проверки, инструмент или проблему с сетью.'
    elif ar:
        lang='ar'; hello='أهلاً يا باشا 👋 أنا NetShield AI. قولّي اللي في دماغك وأنا أربطه بنتيجة الفحص والأدوات لو ينفع.'
    else:
        lang='en'; hello='Hey 👋 I’m NetShield AI. Tell me what you are seeing and I’ll connect it to the current scan and tools.'
    low=q.lower()
    if len(q)<=4 or low in {'hi','hello','hey','yo','سلام','اهلا','هاي','привет','хай'}:
        return {'answer':hello,'language':lang}
    clues=[]
    if b.get('webdriver'): clues.append('WebDriver is exposed')
    if b.get('timezone') and b.get('locale'): clues.append(f"Timezone={b['timezone']} / Locale={b['locale']}")
    if tool: clues.append(f"Last tool: {tool.get('name',tool.get('tool','unknown')) if isinstance(tool,dict) else str(tool)}")
    if score not in (None,'—'): clues.append(f'Score={score}/100')
    evidence=' · '.join(clues) or 'No decisive extra signal is available right now.'
    if any(k in low for k in ['why','risk','score','مخاطر','درجة','ليه','لماذا','почему','риск']):
        if lang=='ar': return {'answer':f'خلينا نفكّها بالأدلة: الدرجة الحالية {score}/100. {evidence}\n\nالدرجة ملخص للإشارات المقاسة، وليست حكمًا على الشخص. لو عايز، ابعت اسم الـTool أو الـCHECK اللي ظهر عندك وأنا أحدد السبب والفحص التالي.'}
        if lang=='ru': return {'answer':f'Разберём по доказательствам: текущий Score {score}/100. {evidence}\n\nЭто итог измеренных сигналов, а не приговор пользователю. Назови инструмент или предупреждение — я подскажу следующий диагностический шаг.'}
        return {'answer':f'Let’s work from evidence: the current score is {score}/100. {evidence}\n\nThat score summarizes measured signals; it is not a verdict about the person. Name the tool or warning and I’ll pick the next diagnostic step.'}
    if any(k in low for k in ['offer','traffic','tracking','postback','attribution','conversion','عرض','ترافيك','تتبع','بوست باك','تحويل','оффер','трафик','постбэк']):
        if lang=='ar': return {'answer':f'خلينا نمشي كتشخيص تقني: {evidence}. ابدأ بـ Redirects → Headers/Security Headers → TLS → DNS → ثم قارن IP/Timezone/Locale/Browser. لو عندك رسالة الخطأ أو نتيجة أداة بعينها ابعتهالي وهربط الأدلة ببعض. مش هاقترح طرق لتجاوز أنظمة الحماية أو الحظر.'}
        if lang=='ru': return {'answer':f'Пойдём как по технической диагностике: {evidence}. Проверь Redirects → Headers/Security Headers → TLS → DNS, затем согласованность IP/часового пояса/локали/браузера. Пришли ошибку или результат инструмента — свяжу факты. Я не подсказываю обход защитных систем или блокировок.'}
        return {'answer':f'Let’s troubleshoot technically: {evidence}. Start with Redirects → Headers/Security Headers → TLS → DNS, then compare IP/timezone/locale/browser consistency. Paste the exact error or tool result and I’ll connect the evidence. I won’t provide ways to bypass security or bans.'}
    if 'ip' in low or 'آي بي' in low or 'ип' in low:
        return {'answer':f'{hello}\n\nCurrent observed public IP: {ip}. Open IP Intelligence, Reverse DNS, Tor and Blacklist to build a stronger picture.' if lang=='en' else (f'{hello}\n\nالـPublic IP الحالي المرصود: {ip}. افتح IP Intelligence وReverse DNS وTor وBlacklist عشان نبني صورة كاملة.' if lang=='ar' else f'{hello}\n\nТекущий публичный IP: {ip}. Открой IP Intelligence, Reverse DNS, Tor и Blacklist, чтобы собрать полную картину.')}
    if lang=='ar': return {'answer':f'تمام. أنا شايف من السياق الحالي: {evidence}. اسألني براحتك عن نتيجة، أداة، جهاز، بصمة، DNS، TLS أو مشكلة Traffic/Offer، وأنا هساعدك خطوة بخطوة.'}
    if lang=='ru': return {'answer':f'Хорошо. По текущему контексту: {evidence}. Спрашивай про результат, инструмент, устройство, fingerprint, DNS, TLS или проблему с traffic/offer — разберём по шагам.'}
    return {'answer':f'Got it. From the current context: {evidence}. Ask about any result, tool, device, fingerprint, DNS, TLS, or traffic/offer issue and I’ll walk through it step by step.'}

@router.get('/referrals')
async def referrals(): return {'proxy':settings.proxy_referral_url or None,'browser':settings.browser_referral_url or None}
