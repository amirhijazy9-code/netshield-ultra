# Security Policy

Only test systems you own or have explicit authorization to test.

Report vulnerabilities privately to the project maintainer. Do not publish
exploits or sensitive data before a fix is available.

The platform's URL/network diagnostic features must use SSRF-safe workers and
must never be used to access private or internal infrastructure.
