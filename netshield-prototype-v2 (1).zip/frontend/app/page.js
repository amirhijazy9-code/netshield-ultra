'use client';
import { useEffect, useMemo, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

function detectBrowser() {
  if (typeof window === 'undefined') return {};
  const nav = navigator;
  let tz = 'Unknown', offset = null;
  try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Unknown'; offset = new Date().getTimezoneOffset(); } catch {}
  let webgl = 'Unavailable';
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
    if (gl) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      webgl = ext ? `${gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)} / ${gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)}` : 'Available (details restricted)';
    }
  } catch {}
  const screenData = `${screen.width}×${screen.height} @ ${window.devicePixelRatio || 1}x`;
  const signals = {
    userAgent: nav.userAgent,
    platform: nav.platform || 'Unknown',
    language: nav.language || 'Unknown',
    languages: nav.languages || [],
    timezone: tz,
    utcOffsetMinutes: offset,
    screen: screenData,
    colorDepth: screen.colorDepth,
    pixelRatio: window.devicePixelRatio || 1,
    hardwareConcurrency: nav.hardwareConcurrency || null,
    deviceMemory: nav.deviceMemory || null,
    touchPoints: nav.maxTouchPoints || 0,
    cookiesEnabled: nav.cookieEnabled,
    doNotTrack: nav.doNotTrack ?? 'Unknown',
    webdriver: !!nav.webdriver,
    online: nav.onLine,
    connection: nav.connection ? { effectiveType: nav.connection.effectiveType, downlink: nav.connection.downlink, rtt: nav.connection.rtt } : null,
    webgl,
    localStorage: canStorage('localStorage'),
    sessionStorage: canStorage('sessionStorage'),
  };
  return signals;
}
function canStorage(type) { try { const s = window[type]; const k='ns_test'; s.setItem(k,'1'); s.removeItem(k); return true; } catch { return false; } }

export default function Home() {
  const [scan, setScan] = useState(null);
  const [browser, setBrowser] = useState({});
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState('overview');
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState([{ role:'assistant', text:'مرحباً! أنا NetShield AI. أقدر أجاوب فقط عن نتائج NetShield وأدواته وشرح بيانات الخصوصية التي يعرضها الموقع.' }]);

  useEffect(() => { setBrowser(detectBrowser()); runScan(); }, []);

  async function runScan() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/full-scan`);
      if (!r.ok) throw new Error('API error');
      setScan(await r.json());
    } catch (e) {
      setScan({ privacy_score: null, findings: [], error: 'Backend is not reachable. Start the API on port 8000.' });
    } finally { setLoading(false); }
  }

  const localRisk = useMemo(() => {
    let score = 0, notes=[];
    if (browser.webdriver) { score += 20; notes.push('Automation indicator is exposed by the browser.'); }
    if (!browser.webgl || browser.webgl === 'Unavailable') { score += 8; notes.push('WebGL details are unavailable.'); }
    if (browser.timezone === 'Unknown') { score += 5; notes.push('Timezone could not be read.'); }
    if (browser.doNotTrack === '1') notes.push('Do Not Track is enabled.');
    return { score: Math.min(100, score), notes };
  }, [browser]);

  const overall = scan?.privacy_score == null ? (100-localRisk.score) : Math.max(0, Math.min(100, Math.round((scan.privacy_score + (100-localRisk.score))/2)));

  function askAI() {
    const q = question.trim(); if (!q) return;
    const lower = q.toLowerCase();
    const allowed = ['ip','privacy','proxy','vpn','fingerprint','browser','timezone','dns','webrtc','risk','score','scan','netshield','webgl','canvas','user agent','ua','report','tool','أى بى','خصوصية','بصمة','متصفح','بروكسي','في بي ان','تايم زون','dns','ريسك','فحص','نتيجة','نت شيلد','أداة'];
    const inScope = allowed.some(x => lower.includes(x));
    let answer = 'أقدر أساعدك فقط في أسئلة تخص NetShield ونتائج الفحص وأدوات الخصوصية الموجودة داخله.';
    if (inScope) {
      if (lower.includes('score') || lower.includes('ريسك') || lower.includes('risk')) answer = `الـ Privacy Score الحالي حوالي ${overall}/100. الدرجة الأعلى تعني حالة خصوصية أفضل في الفحص الحالي. الـBrowser risk المحلي عندك ${localRisk.score}/100.`;
      else if (lower.includes('timezone') || lower.includes('تايم')) answer = `الـ timezone المقروء من المتصفح هو ${browser.timezone || 'غير متاح'} مع UTC offset ${browser.utcOffsetMinutes ?? 'غير متاح'} دقيقة.`;
      else if (lower.includes('fingerprint') || lower.includes('بصمة')) answer = `NetShield يجمع إشارات المتصفح مثل User-Agent والمنصة واللغة والشاشة والـWebGL والـhardware hints ثم يعرضها كإشارات تشخيصية. لا نعتبر إشارة واحدة دليلاً قاطعاً.`;
      else if (lower.includes('ip') || lower.includes('أى بى')) answer = `قسم IP يعرض عنوان الاتصال المتاح للـAPI ونسخته وReverse DNS والمؤشرات الأساسية. بيانات الـISP/ASN والسمعة تحتاج مزود بيانات خارجي عند تفعيله.`;
      else answer = 'دي من نطاق NetShield. افتح التبويب المناسب (IP / Fingerprint / Network / Tools) وأنا أشرح لك البيانات الظاهرة فيه.';
    }
    setMessages(m => [...m, {role:'user',text:q}, {role:'assistant',text:answer}]);
    setQuestion('');
  }

  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="brandmark">N</div><div><b>NETSHIELD</b><span>PRIVACY INTELLIGENCE</span></div></div>
      <div className="top-actions"><span className="live"><i/> SYSTEM READY</span><button onClick={runScan}>{loading ? 'SCANNING…' : '↻ FULL SCAN'}</button></div>
    </header>

    <section className="hero">
      <div><div className="eyebrow">YOUR DIGITAL PRIVACY CONTROL ROOM</div><h1>Know what your<br/><em>connection reveals.</em></h1><p>One focused workspace for IP intelligence, browser fingerprint signals, timezone, network diagnostics and privacy risk.</p></div>
      <div className="score"><div className="ring" style={{'--p':`${overall}%`}}><strong>{overall}</strong><small>/100</small></div><span>PRIVACY SCORE</span><small>{loading ? 'Live scan running' : 'Current browser session'}</small></div>
    </section>

    <nav className="tabs">{[['overview','Overview'],['ip','IP Intelligence'],['fingerprint','Fingerprint'],['network','Network'],['timezone','Timezone'],['tools','Tools'],['ai','NetShield AI']].map(([id,label])=><button className={tab===id?'active':''} onClick={()=>setTab(id)} key={id}>{label}</button>)}</nav>

    {tab==='overview' && <>
      <section className="grid four">
        <Metric label="Public IP" value={scan?.findings?.[0]?.result?.ip || '—'} sub={scan?.findings?.[0]?.result?.version ? `IPv${scan.findings[0].result.version}` : 'Awaiting scan'} />
        <Metric label="Browser" value={browser.platform || '—'} sub={browser.userAgent ? browser.userAgent.slice(0,52)+'…' : 'Reading signals'} />
        <Metric label="Timezone" value={browser.timezone || '—'} sub={browser.utcOffsetMinutes != null ? `UTC ${-browser.utcOffsetMinutes/60 >= 0 ? '+' : ''}${-browser.utcOffsetMinutes/60}` : 'Unknown'} />
        <Metric label="Local Risk" value={`${localRisk.score}/100`} sub={localRisk.score ? 'Review recommended' : 'No local flags'} />
      </section>
      <section className="grid two">
        <Panel title="Signal overview" badge="LIVE"><Rows data={{'User-Agent':browser.userAgent||'—','Language':browser.language||'—','Screen':browser.screen||'—','CPU cores':browser.hardwareConcurrency||'—','Touch points':browser.touchPoints??'—','WebGL':browser.webgl||'—','WebDriver':browser.webdriver?'Exposed':'Not exposed'}} /></Panel>
        <Panel title="Findings" badge={scan?.error?'OFFLINE':'SCAN'}>{scan?.error ? <div className="alert">{scan.error}</div> : (scan?.findings?.length ? scan.findings.map((f,i)=><div className="finding" key={i}><span>{f.category}</span><b>{f.status || 'info'}</b><p>{f.message || JSON.stringify(f.result)}</p></div>) : <div className="empty">No high-level findings. Run a scan to refresh.</div>)}</Panel>
      </section>
    </>}

    {tab==='ip' && <Detail title="IP Intelligence"><Rows data={{'IP address':scan?.findings?.[0]?.result?.ip||'—','Version':scan?.findings?.[0]?.result?.version?`IPv${scan.findings[0].result.version}`:'—','Reverse DNS':scan?.findings?.[0]?.result?.reverse_dns||'Not found','Private address':String(scan?.findings?.[0]?.result?.private??'—'),'Reserved':String(scan?.findings?.[0]?.result?.reserved??'—'),'Loopback':String(scan?.findings?.[0]?.result?.loopback??'—')}} /><p className="muted">Provider-based ASN, ISP, VPN/proxy and reputation intelligence can be connected through backend adapters without changing this UI.</p></Detail>}
    {tab==='fingerprint' && <Detail title="Browser Fingerprint Lab"><Rows data={browser} /><div className="chips">{Object.entries(browser).filter(([k])=>typeof browser[k]==='boolean').map(([k,v])=><span className={v?'warn':''} key={k}>{k}: {String(v)}</span>)}</div></Detail>}
    {tab==='network' && <Detail title="Network Diagnostics"><Rows data={{'Online':String(browser.online??'—'),'Effective connection':browser.connection?.effectiveType||'Unavailable','Downlink':browser.connection?.downlink ? `${browser.connection.downlink} Mbps`:'Unavailable','RTT':browser.connection?.rtt != null ? `${browser.connection.rtt} ms`:'Unavailable','WebRTC': 'Browser-dependent test available','DNS': 'Use Tools → DNS Inspector'}} /><p className="muted">Network APIs expose only what the browser permits. Absence of a signal is not automatically a leak.</p></Detail>}
    {tab==='timezone' && <Detail title="Timezone & Locale"><Rows data={{'IANA timezone':browser.timezone||'—','UTC offset':browser.utcOffsetMinutes != null ? `${browser.utcOffsetMinutes} minutes`:'—','Language':browser.language||'—','Languages':browser.languages?.join(', ')||'—','24-hour preference':'Browser locale dependent'}} /></Detail>}
    {tab==='tools' && <Tools browser={browser} />}
    {tab==='ai' && <section className="ai-wrap"><div className="ai-head"><div className="ai-orb">✦</div><div><div className="eyebrow">SCOPED ASSISTANT</div><h2>NetShield AI</h2><p>Answers only about this website, its scans, tools and displayed privacy data.</p></div></div><div className="chat">{messages.map((m,i)=><div className={m.role} key={i}>{m.text}</div>)}</div><div className="composer"><input value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>e.key==='Enter'&&askAI()} placeholder="Ask about your NetShield scan…"/><button onClick={askAI}>SEND</button></div></section>}

    <footer><div><b>NETSHIELD</b><span>Privacy Intelligence Platform</span></div><div className="support">Support: <strong>@NetShieldSupport</strong> · netshieldprosupport@gmail.com</div><div className="partners"><a href="https://www.adspower.com/share/GXxIGf" target="_blank" rel="noreferrer">Browser partner</a><a href="https://iproyal.com/?r=1528614" target="_blank" rel="noreferrer">Proxy partner</a></div></footer>
  </main>
}

function Metric({label,value,sub}) { return <div className="metric"><span>{label}</span><strong title={value}>{value}</strong><small>{sub}</small></div> }
function Panel({title,badge,children}) { return <section className="panel"><div className="panel-title"><h3>{title}</h3><span>{badge}</span></div>{children}</section> }
function Detail({title,children}) { return <section className="detail"><div className="detail-title"><div className="eyebrow">DIAGNOSTIC MODULE</div><h2>{title}</h2></div><div className="detail-body">{children}</div></section> }
function Rows({data}) { return <div className="rows">{Object.entries(data||{}).map(([k,v])=><div className="row" key={k}><span>{pretty(k)}</span><b>{Array.isArray(v)?v.join(', '):String(v)}</b></div>)}</div> }
function pretty(s){ return s.replace(/([A-Z])/g,' $1').replace(/^./,x=>x.toUpperCase()); }
function Tools({browser}) { return <div className="toolgrid"><Tool name="Fingerprint Snapshot" desc="Capture the browser signals currently exposed to this page." onClick={()=>alert(JSON.stringify(browser,null,2))}/><Tool name="Timezone Check" desc="Show timezone, offset and locale information." onClick={()=>alert(`${browser.timezone||'Unknown'}\nUTC offset: ${browser.utcOffsetMinutes ?? 'Unknown'} minutes\nLocale: ${browser.language||'Unknown'}`)}/><Tool name="WebGL Inspector" desc="Inspect the WebGL availability and renderer signal." onClick={()=>alert(browser.webgl||'WebGL unavailable')}/><Tool name="Storage Test" desc="Check whether local and session storage are available." onClick={()=>alert(`localStorage: ${browser.localStorage}\nsessionStorage: ${browser.sessionStorage}`)}/><Tool name="DNS Inspector" desc="Backend DNS records tool is available through the API." onClick={()=>alert('Use POST /api/dns with a domain in the API docs.')}/><Tool name="JSON Report" desc="Export the current browser signal snapshot as JSON." onClick={()=>downloadJSON(browser)}/></div> }
function Tool({name,desc,onClick}) { return <button className="tool" onClick={onClick}><div><b>{name}</b><p>{desc}</p></div><span>→</span></button> }
function downloadJSON(data){ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})); a.download='netshield-browser-report.json'; a.click(); }
