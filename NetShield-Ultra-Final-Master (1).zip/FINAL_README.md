# NetShield Ultra — Intelligence Edition

This release is the production-oriented master build for the NetShield Ultra frontend + FastAPI diagnostics backend.

## What is materially upgraded

- Evidence-based state model: PASS / WARNING / FAIL / UNAVAILABLE / WAITING.
- Automatic first-load audit with no manual refresh requirement.
- 36-tool toolbox with real local/server diagnostics where supported.
- Explicit input handling for domain, URL, IP, CIDR and DKIM selector checks.
- Full investigation flow combining browser and server evidence.
- Device/environment lab with honest confidence language; no unsupported claim of physical vs cloud hardware.
- Multilingual UI and AI conversation: Arabic, English and Russian.
- Conversational AI behavior: short greetings and normal human messages receive normal responses instead of a hard scope rejection. Product scope is retained for diagnostic content.
- Optional OpenAI-compatible AI provider via `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`.
- Built-in contextual fallback when no model provider is configured.
- Exportable JSON reports.
- NetShield-branded SEO/OpenGraph metadata and canonical production URL.
- Offer/traffic diagnostics limited to legitimate troubleshooting and measurement quality; no anti-fraud bypass instructions.

## Backend deployment

GitHub Pages / Cloudflare Pages can host the Next.js frontend. The FastAPI backend must be deployed separately and the frontend must have `NEXT_PUBLIC_API_URL` pointing to it.

For AI, set the optional `AI_*` environment variables on the backend. Never put provider API keys into frontend code.

## Current official frontend

https://netshield-ultra.pages.dev/
