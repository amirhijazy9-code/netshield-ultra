import './globals.css';

export const metadata = {
  title: 'NetShield Ultra — Privacy Intelligence',
  description: 'Privacy, IP, browser and network diagnostics in one dashboard.'
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
